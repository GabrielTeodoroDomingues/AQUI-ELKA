<?php
    $nomeSistema = "Portal do Surf";
    // $usuario = ["nome"=>"Stephania"];

    // $nomeArquivo = "produto.json";
    // $produtos = json_decode(file_get_contents($nomeArquivo), true);
    // para fazer o correto upload de fotos:


?>
